export default {
  mappings: {
    section: {
      title: 'Section',
      fieldType: ['number', 'string']
    }
  }
}
